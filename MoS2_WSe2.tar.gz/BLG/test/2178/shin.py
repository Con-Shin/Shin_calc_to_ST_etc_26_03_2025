import numpy as np
from ase import Atoms
from ase.build import mx2, graphene
from ase.visualize import view
import os
from msspec.iodata import Data
#from iodata import Dataset
from ase  import Atom, Atoms
import numpy as np
from msspec.calculator import MSSPEC, XRaySource
from msspec.utils import *
from ase.visualize import view
import shutil
from msspec.looper import Sweep, Looper

#calc_path = "../../28_06_2024/"
#import sys
#sys.path.append(calc_path)
#from Cone_making import Cone_making

## functions for renormalization studies
#from studies.load_from_file import load_from_stream
#from studies.MsMatrix import MsMatrix
#from studies.find_optimal_spectral_radius import find_optimal_spectral_radius

def calculate_superlattice_period(a1, a2, theta):
    """
    超格子の周期 L を計算する。

    Parameters:
    a1 (float): bottom 層の格子定数
    a2 (float): top 層の格子定数
    theta (float): 回転角 (度単位)

    Returns:
    float: 超格子周期 L
    """
    theta_rad = np.radians(theta)  # 角度をラジアンに変換
    numerator = a1 * a2
    denominator = np.sqrt(a1**2 + a2**2 - 2 * a1 * a2 * np.cos(theta_rad))
    return numerator / denominator

def rotate_layer(atoms, theta, center=(0, 0, 0)):
    """
    上層の原子を回転させる。

    Parameters:
    atoms (Atoms): ASEの Atoms オブジェクト
    theta (float): 回転角 (度単位)
    center (tuple): 回転中心 (デフォルトは原点)

    Returns:
    Atoms: 回転後の Atoms オブジェクト
    """
    theta_rad = np.radians(theta)
    rotation_matrix = np.array([
        [np.cos(theta_rad), -np.sin(theta_rad), 0],
        [np.sin(theta_rad),  np.cos(theta_rad), 0],
        [0, 0, 1]
    ])

    positions = atoms.get_positions() - np.array(center)
    rotated_positions = np.dot(positions, rotation_matrix.T) + np.array(center)
    atoms.set_positions(rotated_positions)
    return atoms

def create_twisted_bilayer(formula1, formula2, a1, a2, thickness1, thickness2, theta, interlayer_distance=6.5, vacuum=15):
    """
    ねじれた二層構造を作成する。

    Parameters:
    formula1 (str): bottom 層の化学式 (例: 'MoS2')
    formula2 (str): top 層の化学式 (例: 'WSe2')
    a1 (float): bottom 層の格子定数
    a2 (float): top 層の格子定数
    thickness1 (float): bottom 層の厚み
    thickness2 (float): top 層の厚み
    theta (float): top 層の回転角 (度単位)
    interlayer_distance (float): 層間距離 (Å, デフォルト 6.5 Å)
    vacuum (float): 真空層 (Å, デフォルト 15 Å)

    Returns:
    Atoms: ねじれ二層構造の Atoms オブジェクト
    """
    # 超格子周期を計算
    L = calculate_superlattice_period(a1, a2, theta)
#    L = 6.51
#    print(L)
    # Bottom 層を作成
    bottom_layer = mx2(formula=formula1, kind='2H', a=a1, thickness=thickness1, size=(1, 1, 1), vacuum=None)
#    bottom_layer = mx2(formula=formula1, kind='2H', a=a1, thickness=thickness1, vacuum=None)
    bottom_layer.positions[:, 2] += vacuum / 2 # z位置を調整
    bottom_layer = bottom_layer.repeat([70,70,1])
#    bottom_layer.set_cell([[L, 0, 0], [L / 2, L * np.sqrt(3) / 2, 0], [0, 0, vacuum + thickness1 + thickness2 + interlayer_distance]])
#    bottom_layer.center(vacuum, axis=2)
#    bottom_layer.rotate(60.,'z')

#    bottom_layer = bottom_layer.translate([0,0,-16.595])

    # Top 層を作成し、回転
    top_layer = mx2(formula=formula2, kind='2H', a=a2, thickness=thickness2, size=(1, 1, 1), vacuum=None)
#    top_layer = mx2(formula=formula2, kind='2H', a=a2, thickness=thickness2, vacuum=None)
#    top_layer = rotate_layer(top_layer, theta, center = (-9.840, -17.043, 0.000))
    top_layer.positions[:, 2] += vacuum / 2 + thickness1 + interlayer_distance# 上に配置
#    top_layer.rotate(21.79, 'z')
#    top_layer.positions[:, 2] += thickness1 + interlayer_distance
    top_layer = top_layer.repeat([70,70,1])
#    top_layer.set_cell([[L, 0, 0], [L / 2, L * np.sqrt(3) / 2, 0], [0, 0, vacuum + thickness1 + thickness2 + interlayer_distance]])
#    top_layer.center(vacuum, axis=2)
    top_layer.rotate(60.,'z')
    bottom_layer.rotate(60.,'z')
#    top_layer.translate([13.530, -23.435, 0.0])
#    bottom_layer.translate([13.530, -23.435, 0.0])
#    top_layer = rotate_layer(top_layer, theta, center = (0.0, 0.0, 18.460))
    top_layer = rotate_layer(top_layer, theta, center = (-17.380, 161.462, 26.285))
#    top_layer = top_layer.translate([0,0,-16.595])

#    top_layer.set_cell([[6.150,-2.130,0], [4.920,4.261,0], [0, 0, vacuum + thickness1 + thickness2 + interlayer_distance]])
#    bottom_layer.set_cell([[6.150,-2.130,0], [4.920,4.261,0], [0, 0, vacuum + thickness1 + thickness2 + interlayer_distance]])
#    top_layer.set_cell([[L, 0, 0], [-L / 2, L * np.sqrt(3) / 2, 0], [0, 0, vacuum + thickness1 + thickness2 + interlayer_distance]])
#    bottom_layer.center(vacuum, axis=2)
#    bottom_layer.set_cell([[L, 0, 0], [-L / 2, L * np.sqrt(3) / 2, 0], [0, 0, vacuum + thickness1 + thickness2 + interlayer_distance]])
#    top_layer.center(vacuum, axis=2)
    # 2つの層を結合
#    bilayer = bottom_layer + top_layer
#    bilayer = rotate_layer(bilayer, 60.0, center = (0.0, 0.0, 0.0))
 #   theta_rad = np.radians(theta)
#    rotation_matrix = np.array([[np.cos(theta_rad), -np.sin(theta_rad), 0],[np.sin(theta_rad),  np.cos(theta_rad), 0],[0, 0, 1]])

    e = a2/(a1) - 1.0

#    top_layer = rotate_layer(top_layer, theta, center = (-19.680, 31.246, 18.460))

    theta_rad = np.radians(theta)

    F1 = 2*(1+e)*np.cos(theta_rad)-(1+e)**2-1
    L1_x = a1*((1+e)*np.cos(theta_rad)-(1+e)**2)/(F1)
    L1_y = a1*((1+e)*np.sin(theta_rad)) / (F1)
    L1 = np.array([L1_x, L1_y, 0.0])
#    length_L1 = np.linalg.norm(L1)
#    print(length_L1)

    F2 = 2*(1/(1+e)-2*np.cos(theta_rad)+(1+e))

    L2_x = a1*((1+e)+(np.sqrt(3)*np.sin(theta_rad)-np.cos(theta_rad)))/(F2)
    L2_y = a1*(np.sqrt(3)*(1+e)-(np.sqrt(3)*np.cos(theta_rad)+np.sin(theta_rad)))/(F2)
    L2 = np.array([L2_x, L2_y, 0.0])

#    print(np.linalg.norm(L2))

#    bilayer.set_cell([[L, 0, 0], [L / 2, L * np.sqrt(3) / 2, 0], [0, 0, vacuum + thickness1 + thickness2 + interlayer_distance]])
    bilayer = bottom_layer + top_layer
    bilayer.set_cell([[L1[0],L1[1],0.0], [L2[0],L2[1],0.0], [0, 0, vacuum + thickness1 + thickness2 + interlayer_distance]])
#    bilayer.set_cell([[6.150,-2.130,0], [4.920,4.261,0], [0, 0, vacuum + thickness1 + thickness2 + interlayer_distance]])
    bilayer.center(vacuum, axis=2)
#    bilayer = rotate_layer(bilayer, 60.0, center = (0.0, 0.0, 0.0))
#    bilayer.rotate(60.,'z')

    return bilayer, L, L1, L2

def calculate_number(L, a1=3.28, a2=3.16):
    """
    超格子内に含まれる原子数を計算する。

    Parameters:
    L (float): 超格子の周期
    a1 (float): bottom 層の格子定数
    a2 (float): top 層の格子定数
    formula1 (str): bottom 層の化学式
    formula2 (str): top 層の化学式
    thickness1 (float): bottom 層の厚み
    thickness2 (float): top 層の厚み

    Returns:
    int: 超格子内の原子数
    """

    # 超格子内にフィットする単位格子の数を計算
    # 超格子周期を用いて、x軸、y軸方向にどれだけの単位格子が配置できるか
    ratio_bottom = L**2/(a1**2)
    ratio_top = L**2/(a2**2)

#    top = 2*ratio_top
#    bottom = 2*ratio_bottom

    # 超格子内の原子数
    total_atoms = ratio_bottom
    return total_atoms


def calculate_atoms_in_superlattice(a1, a2, formula1, formula2, thickness1, thickness2):
    """
    超格子内に含まれる原子数を計算する。

    Parameters:
    L (float): 超格子の周期
    a1 (float): bottom 層の格子定数
    a2 (float): top 層の格子定数
    formula1 (str): bottom 層の化学式
    formula2 (str): top 層の化学式
    thickness1 (float): bottom 層の厚み
    thickness2 (float): top 層の厚み

    Returns:
    int: 超格子内の原子数
    """
    # 単位格子を作成
    bottom_layer = mx2(formula=formula1, kind='2H', a=a1, thickness=thickness1)
    top_layer = mx2(formula=formula2, kind='2H', a=a2, thickness=thickness2)

    # 1層あたりの原子数を取得
    atoms_in_bottom_layer = len(bottom_layer)
    atoms_in_top_layer = len(top_layer)

    # 超格子内にフィットする単位格子の数を計算
    # 超格子周期を用いて、x軸、y軸方向にどれだけの単位格子が配置できるか
    num_cells_x = int(L / a1)
    num_cells_y = int(L / a2)

    # 超格子内の原子数
    total_atoms = (atoms_in_bottom_layer + atoms_in_top_layer) * num_cells_x * num_cells_y
    return total_atoms

BL, L, L1, L2 = create_twisted_bilayer(formula1='WSe2', formula2='MoS2', a1=3.28, a2=3.16, thickness1=3.19, thickness2=3.19, theta=21.78, interlayer_distance=6.50, vacuum=15)
total_atoms= calculate_number(L=L, a1=3.28, a2=3.16)
#print(top)
#print(bottom)
#print(top + bottom)
#print(L)
print(total_atoms)
#exit(0)
###########################################################
import numpy as np
from ase import Atoms
from ase.io import read
import os

def is_inside_parallelogram(x, y, L1, L2, th_min_u, th_max_u, th_min_v, th_max_v):
    """
    W原子が超格子の平行四辺形の内部にあるか判定する関数。

    :param x: 原子の x 座標
    :param y: 原子の y 座標
    :param L: 格子定数
    :return: True（内部） or False（外部）
    """

#    a1 = np.array([6.150, -2.130])
#    a2 = np.array([4.920, 4.261])

    # 平行四辺形の原点を(0,0)とする
    v = np.array([x, y])

    # 逆行列を用いて基底ベクトルの係数を求める
    A = np.column_stack([L1[:2], L2[:2]])  # 行列 [a1, a2]
    coeffs = np.linalg.solve(A, v)

    u, v = coeffs  # 平行四辺形内の重み係数

    # (0 <= u <= 1) かつ (0 <= v <= 1) ならば、平行四辺形内
    return (th_min_u < u < th_max_u) and (th_min_v < v < th_max_v)

import concurrent.futures
from scipy.spatial import cKDTree
from ase import Atoms

#def process_center(args):
#    center, atoms, tree, positions, radius, z_range = args
#    x_c, y_c, z_c = center
#    idxs = tree.query_ball_point([x_c, y_c, z_c], radius, p=2)
#    selected_atoms = [atoms[i] for i in idxs if z_range[0] <= (positions[i, 2] - z_c) <= z_range[1]]

#    if selected_atoms:
#        return Atoms(selected_atoms), center, radius, z_range[1] - z_range[0]
#    return None

def process_center(args):
    center, atoms, tree_2d, positions, radius, z_range = args
    x_c, y_c, z_c = center  # 中心原子の位置（円柱の底面の中心）
#
#    # 1. xy 平面で半径 radius 以内の原子を取得（z は無視）
    idxs = tree_2d.query_ball_point([x_c, y_c], radius, p=2)
#
#    # 2. 取得した原子の中から、中心原子の z_c を底面として z_range 内にあるものを選択
    selected_atoms = [
        atoms[i] for i in idxs if z_c + z_range[0] <= positions[i, 2] <= z_c + z_range[1]
    ]
#
    if selected_atoms:
        return Atoms(selected_atoms), center, radius, z_range[1] - z_range[0]
    return None
#

#def process_center(args):
#    center, atoms, tree, positions, radius, z_range = args
#    x_c, y_c, z_c = center
#    idxs = tree.query_ball_point([x_c, y_c, z_c], radius, p=2)
#    selected_atoms = [atoms[i] for i in idxs if z_range[0] <= (positions[i, 2] - z_c) <= z_range[1]]
#
#    if selected_atoms:
#        return Atoms(selected_atoms), center, radius, z_range[1] - z_range[0]
#    return None
#
def extract_cylindrical_clusters_parallel(atoms, element="W", radius=3.0, z_range=(0.0, 10.0), L1=np.array([1, 0]), L2=np.array([1, 0]), th_min_u=-0.1, th_max_u=1, th_min_v=0, th_max_v=1):
    clusters = []
    centers = []
    radii = []
    heights = []

    # 指定された要素を持つ原子の位置を取得し、条件に合う原子のみ抽出
    w_positions = np.array([
        atom.position for atom in atoms 
        if atom.symbol == element and is_inside_parallelogram(atom.x, atom.y, L1, L2, th_min_u, th_max_u, th_min_v, th_max_v)
    ])
    if len(w_positions) == 0:
        return clusters, centers, radii, heights

    # すべての原子の3D位置を取得
    positions = np.array([atom.position for atom in atoms])

    # 2D KD-tree (x, y のみ) を作成
    positions_2d = np.array([[pos[0], pos[1]] for pos in positions])  # x, y のみ
    tree_2d = cKDTree(positions_2d)

    # 並列処理でクラスタを抽出
    with concurrent.futures.ProcessPoolExecutor(max_workers=20) as executor:
        results = executor.map(process_center, [
            (center, atoms, tree_2d, positions, radius, z_range) for center in w_positions
        ])

    for result in results:
        if result:
            cluster, center, r, h = result
            clusters.append(cluster)
            centers.append(center)
            radii.append(r)
            heights.append(h)

    return clusters, centers, radii, heights

##def extract_cylindrical_clusters(atoms, element="W", radius=3.0, z_range=(-5.0, 5.0), L=10.0, th_min=0, th_max=1):
#    """
#    Atoms オブジェクトから特定の元素を中心に、超格子の平行四辺形内にあるW原子を中心とする円柱クラスターを作成。
#
#    :param atoms: ASEのAtomsオブジェクト
#    :param element: 中心とする元素 (デフォルト: W)
#    :param radius: 円柱の半径
#    :param z_range: 円柱のz方向の範囲 (min, max)
#    :param L: 格子定数
#    :return: (clusters, centers, radii, heights)
#        - clusters: 各円柱内のAtomsオブジェクトのリスト
#        - centers: 各円柱の中心 (W原子の座標)
#        - radii: 各円柱の半径リスト
#        - heights: 各円柱の高さリスト
#    """
#    clusters = []
#    centers = []
#    radii = []
#    heights = []
#
#    # W原子の座標を取得（平行四辺形内にあるものだけ）
#    w_positions = [atom.position for atom in atoms if atom.symbol == element and is_inside_parallelogram(atom.x, atom.y, L, th_min, th_max)]
##    w_positions = [w_positions[0], w_positions[1], w_positions[5], w_positions[6]]
#
#    for center in w_positions:
#        x_c, y_c, z_c = center
#
#        # 円柱内にある原子をフィルタリング
#        selected_atoms = []
#        for atom in atoms:
#            x, y, z = atom.position
#            if (x - x_c) ** 2 + (y - y_c) ** 2 <= radius ** 2 and z_range[0] <= (z - z_c) <= z_range[1]:
#                selected_atoms.append(atom)
#
#        # 新しい Atoms オブジェクトを作成
#        if selected_atoms:
#            clusters.append(Atoms(selected_atoms))
#            centers.append(center)
#            radii.append(radius)
#            heights.append(z_range[1] - z_range[0])
#
#    return clusters, centers, radii, heights

#top_layer.translate([-12.300, -19.884, -15.000])
#bottom_layer.translate([-12.300, -19.884, -15.000])
#top_layer.translate([0.000, 0.000, 3.460])
#bottom_layer.translate([-12.300, -19.884, 0.000])

from numba import njit, prange

@njit(parallel=True)
def translate_positions(positions, displacement):
    for i in prange(positions.shape[0]):
        positions[i, 0] += displacement[0]
        positions[i, 1] += displacement[1]
        positions[i, 2] += displacement[2]

def parallel_translate(atoms: Atoms, displacement):
    displacement = np.asarray(displacement, dtype=np.float64)
    translate_positions(atoms.positions, displacement)

#BL.translate([-12.300, -19.884, -15.000])
#BL.translate([41.820, -80.956, -15.000])
#parallel_translate(BL, [-26.860, -117.676, -15.750-0.845])
parallel_translate(BL, [17.380, -161.462, -15.750-0.845])
##16.112
#BL.rotate(90., 'z')
#print(L)
#view(BL)
#exit(0)

#view(bottom_layer)
#exit(0)
#clusters_top, centers_top, radii_top, heights_top = extract_cylindrical_clusters(top_layer, element='C', radius=14.0, z_range=(-10.0, 10.0), L=L, th_min=-0.0001, th_max=1)
#view(bottom_layer)
#clusters_bottom, centers_bottom, radii_bottom, heights_bottom = extract_cylindrical_clusters(bottom_layer, element='C', radius=14.0, z_range=(-10.0, 10.0), L=L, th_min=-0.0001, th_max=1)

clusters, centers, radii, heights = extract_cylindrical_clusters_parallel(BL, element='W', radius=20.0, z_range=(-10.0, 15.0), L1=L1, L2=L2, th_min_u=0.0, th_max_u=1, th_min_v=0.0, th_max_v=1)
#print(clusters)
#top_layer.translate([13.530, -23.435, -15.000])
#bottom_layer.translate([13.530, -23.435, -15.000])
#view(top_layer)
#view(bottom_layer)

# カウント
z_zero_count = sum(1 for arr in centers if arr[2] == 0)
z_nonzero_count = sum(1 for arr in centers if arr[2] != 0)

# 結果を表示
print(f"z座標が0の配列数: {z_zero_count}")
print(f"z座標が0でない配列数: {z_nonzero_count}")

#view(BL)
#print(centers)
#view(clusters[18])
#print(centers[18])
#view(clusters[1])
#print(centers[1])
#print(len(clusters))
#print(len(centers))
#exit(0)
#print(len(clusters))
#centers.insert(0, np.array([0.0, 0.0, 0.0]))
#print(centers)
#exit(0)
#del clusters_bottom[8]
#del centers_bottom[8]
#print(len(clusters_top))
#print(centers_top)
#print(len(clusters_bottom))
#print(centers_bottom)
#del clusters[4]
#del centers[4]
#print(len(centers))
#print(centers[1:14])
#exit(0)
#view(clusters[0])
#view(clusters[14])
#print(centers[0])
#print(centers[14])
#exit(0)
#exit(0)
#view(clusters_bottom[0])
#exit(0)
#clusters = []
#for i in range(14):
        # 0 <= i < 14 の場合は clusters_top[i] と bottom_layer を組み合わせる
#    clusters.append(clusters_top[i] + )
        # 14 <= i < 28 の場合は clusters_bottom[i] と top_layer を組み合わせる
#for j in range(14):

#    clusters.append(clusters_bottom[j] + top_layer)

#centers = centers_top + centers_bottom
#print(len(clusters))
#print(centers)
#exit(0)
#view(clusters[0])
#exit(0)
#view(clusters[0])
#print(centers[0])
#print(centers[0])
#view(clusters[1])
#view(clusters[5])
#print(centers[1])
#view(clusters[2])
#print(centers[2])
#view(clusters[3])
#print(centers[3])

#exit(0)

# 例: Atomsオブジェクトの読み込み
#atoms = read("structure.xyz")  # 任意の構造ファイルを指定
#BL.translate([-9.960, -17.251, 0.00])
#print(len(clusters))
#print(len(centers))
#exit(0)
#view(BL)
#view(clusters[10])
#print(centers[10])
#exit(0)
# 結果の確認
##########################################################
from mpi4py import MPI
from multiprocessing import Pool, cpu_count

#total_cross_section = 0
#calc = MSSPEC(spectroscopy = 'PED',algorithm = 'expansion')
#calc.calculation_parameters.scattering_order = 1
#calc.tmatrix_parameters.lmax_mode = "imposed"
#calc.tmatrix_parameters.lmaxt = 19
#calc.muffintin_parameters.radius_overlapping = 0.0
#calc.muffintin_parameters.charge_relaxation = True
#
#calc.tmatrix_parameters.exchange_correlation = "hedin_lundqvist_complex"
##incident light energy and angle
#calc.source_parameters.energy = XRaySource.AL_KALPHA    # 0 <= value
#calc.source_parameters.theta = 89.           # -180.0 <= value <= 180.0
#calc.source_parameters.phi = 0.             # -180.0 <= value <= 180.0
#
#L = len(clusters)
#####################################################################################################
#import concurrent.futures
#dset_common_value = {"theta": [], "phi": []}
#print(dset_common_value["ke"])
#exit(0)
import copy
#import concurrent.futures


#print(len(BL_copies))
#view(BL_copies[0])
#view(BL_copies[27])
#exit(0)
import multiprocessing

#radii = (('Mo', 1.39),('S', 1.80),('W', 1.39), ('Se', 1.20))

#for s, r in radii:
#    [atom.set('mt_radius',r) for atom in cluster if atom.symbol == s]
#save = multiprocessing.Manager().list()
#clusters = clusters[:40]
#centers = centers[:40]
#l = len(clusters) // 10 + 1

#print(l)
#exit(0)

import concurrent.futures
import os
import time
from concurrent.futures import ProcessPoolExecutor
import numpy as np

#os.environ["OMP_NUM_THREADS"] = "1"  # スレッド数を1に制限
# 17番目と18番目のクラスターとセンターを取得

radii = (('Mo', 1.39),('S', 1.00),('W', 1.39), ('Se', 1.00))

def compute_cross_section(i):
 
    calc = MSSPEC(spectroscopy='PED', algorithm='expansion', folder=f'calc_{i}')
    calc.calculation_parameters.scattering_order = 1
    calc.tmatrix_parameters.lmax_mode = "imposed"
    calc.tmatrix_parameters.lmaxt = 20
    calc.muffintin_parameters.interstitial_potential = 12.5
    
    for atom in clusters[i]:
        atom.set('mean_square_vibration', 5e-03)
    
    for s, r in radii:
        [atom.set('mt_radius',r) for atom in clusters[i] if atom.symbol == s]

    calc.calculation_parameters.vibrational_damping = 'averaged_tl'
    calc.muffintin_parameters.charge_relaxation = True
    calc.detector_parameters.average_sampling = 'medium'
    calc.detector_parameters.angular_acceptance = 1.5
    calc.tmatrix_parameters.exchange_correlation = "hedin_lundqvist_complex"
    calc.source_parameters.energy = XRaySource.AL_KALPHA
    calc.source_parameters.theta = -45.0
    calc.source_parameters.phi = 0.0
    calc.calculation_parameters.RA_cutoff = 2

#    calc.calculation_parameters.renormalization_mode = 'G_n'
#    calc.calculation_parameters.renormalization_omega = 0.85 + 0.1j

    clusters[i].translate([-1*centers[i][0], -1*centers[i][1], -1*centers[i][2]])    
    clusters[i].absorber = get_atom_index(clusters[i], 0, 0, 0)
    calc.set_atoms(clusters[i])
    
    data = calc.get_theta_phi_scan(level='4s', kinetic_energy=1000)
    dset = data[-1]

    theta_value = dset.theta
    phi_value = dset.phi
    k_value = dset.energy
    d_value = dset.direct_signal
     
    calc.shutdown()
    return dset.cross_section, theta_value, phi_value, k_value, d_value

total_cross_section = 0
theta_values = 0
phi_values = 0
k_values = 0
d_values = 0
# 並列処理のためにProcessPoolExecutorを使用
with concurrent.futures.ProcessPoolExecutor(max_workers=7) as executor:
    results = executor.map(compute_cross_section, range(len(clusters)))

#exit(0)
for idx, (cross_section, theta, phi, k, d) in enumerate(results):
        # 最初の計算結果のthetaとphiを一度だけ追加
    if idx == 0:

        theta_values += theta
        phi_values += phi
        k_values += k
        # cross_sectionを合計
    total_cross_section += cross_section
    d_values += d

    mask = theta_values < 65
    filtered_theta = theta_values[mask]
    filtered_phi = phi_values[mask]
    filtered_cross_section = total_cross_section[mask]
    filtered_ke = k_values[mask]
    filtered_d = d_values[mask]
 
######################################################################################################
FOLDER = "output"  # 出力フォルダを設定
ke = 890
level = '4s'
# 最終的な結果をファイルに保存
data = Data('theta_phi scan [0]')
dset = data.add_dset(f"PED {54} atoms")
dset.add_columns(theta=filtered_theta, phi=filtered_phi, energy=filtered_ke, cross_section=filtered_cross_section, direct_signal=filtered_d)
#                absorber_symbol = self.atoms[self.atoms.absorber].symbol
title = ('Stereographic projection of {}({}) at {:.2f} eV''').format('W', level, 890)
xlabel = r'Angle $\phi$($\degree$)' 
ylabel = r'Signal (a. u.)'
view = dset.add_view("E = {:.2f} eV".format(ke), title=title, xlabel=xlabel, ylabel=ylabel,
    projection='stereo', colorbar=True, autoscale=True)

view.select('theta', 'phi', 'cross_section')

data.view()
data.export(os.path.join(FOLDER, 'result_plot'))
fn = os.path.join(FOLDER, 'plot.hdf5')
data.save(fn)
##########################################################

############################################################

#for s, r in radii:
#    [atom.set('mt_radius',r) for atom in BL if atom.symbol == s]

#def Cone_100():
#Select SrSr chain on x axis
#    BL.rotate(90.,'y')
#    Cone_1 = Cone_making(BL,0.1,25)
#    L1 = len(Cone_1)
#    BL.rotate(-90.,'y')
#    Cone_1.rotate(-90.,'y')
#Select SrSr chain on y axis
#    BL.rotate(90.,'x')
#    Cone_2 = Cone_making(BL,0,2)
#    L2 = len(Cone_2)
#    BL.rotate(-90.,'x')
#Select SrSr chain on z axis
#    Cone_3 = Cone_making(BL,0,2)
#    L3 = len(Cone_3)
#create a map with cones and their lengths
#    clusters = {
#    L1: Cone_1,
#    L2: Cone_2,
#    L3: Cone_3,
    # Add more mappings as needed
#}
#select a maximum-length chain
#    Lmax = max(L1,L2,L3)
#    Cone_100 =  clusters[Lmax]
#    return Cone_1

#BL = Cone_100()
#calc = MSSPEC(spectroscopy = 'PED',algorithm = 'expansion')
##BL.absorber = get_atom_index(BL,19.920, 34.502, 0.000)
##BL.absorber = get_atom_index(BL, 1.660, 2.875, 0.000)
##BL.absorber = get_atom_index(BL, 0.000, 0.000, 0.000)
#calc.set_atoms(BL)
#calc.calculation_parameters.scattering_order = 1
##calc.global_parameters.algorithm = "expansion"
##calc.global_parameters.polarization = 'linear_qOz'
#calc.tmatrix_parameters.lmax_mode = "imposed"
#calc.tmatrix_parameters.lmaxt = 19
#calc.muffintin_parameters.radius_overlapping = 0.0
#calc.muffintin_parameters.charge_relaxation = True
#
#calc.tmatrix_parameters.exchange_correlation = "hedin_lundqvist_complex"
#
##radii = (('N', 0.5823640000),('O', 0.5684360000))
#
##for s, r in radii:
##[atom.set('mt_radius',1.5) for atom in BL]
#
##incident light energy and angle
#calc.source_parameters.energy = XRaySource.AL_KALPHA    # 0 <= value
#calc.source_parameters.theta = 89.           # -180.0 <= value <= 180.0
#calc.source_parameters.phi = 0.             # -180.0 <= value <= 180.0
#
## Renormalization
##calc.calculation_parameters.renormalization_mode = 'G_n'
##calc.calculation_parameters.renormalization_omega = 0.7860213069579177+0.06035575102957445j
#
#all_data = calc.get_energy_scan(phi=0, theta=90, level='4s', kinetic_energy = [890, 900, 10])
##all_data = calc.get_theta_phi_scan(level='4s', kinetic_energy=890)
#all_data.view()

#view(BL)
#BL = BL.repeat([10,10,1])
#view(BL)
#exit(0)
# 例
#L = calculate_superlattice_period(a1=3.18, a2=3.32, theta=0.1)
#atoms_count = calculate_number(L, a1=3.18, a2=3.32)
#print(L)
#print(f"超格子内に含まれる原子数: {atoms_count}")
